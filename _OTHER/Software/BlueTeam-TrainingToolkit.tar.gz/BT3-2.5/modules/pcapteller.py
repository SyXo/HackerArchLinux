#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import cmd, os, sys, re
import importlib, signal, zipfile, socket
import libs.bt3out, libs.bt3in, libs.bt3api

import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from scapy.all import *
from datetime import datetime


__module_name__    = "Pcapteller"
__module_version__ = "1.8"


class Options():

    def __init__(self):
        self.file              = ""
        self.fragmentation     = False
        self.interface         = ""
        self.mtu               = "1500"
        self.pcap_ip_list      = ""
        self.pcap_mac_list     = ""
        self.pcap_pld_list     = ""
        self.proto_layer_list  = ""
        self.real_time         = False
        self.wire_ip_list      = ""
        self.wire_mac_list     = ""
        self.wire_pld_list     = ""
        self.options           = ""
        self.proto_layer_support = ["DNS", "RAW", "SMB", "NBNS"]

    def get_options(self):
        self.options = [["FILE", str(self.file), "True", "Pcap file to replay in libpcap format."],
                        ["FRAGMENTATION", str(self.fragmentation), "True", "Fragment packets during replay. Useful for networks with low MTU."],
                        ["INTERFACE", str(self.interface), "True", "Network interface to replay the packets with."],
                        ["MTU", str(self.mtu), "True", "MTU to use with packet fragmentation."],
                        ["PCAP_IP_LIST", str(self.pcap_ip_list), "False", "Comma-separated list of IP addresses to replace as seen on the pcap file."],
                        ["PCAP_MAC_LIST", str(self.pcap_mac_list), "False", "Comma-separated list of MAC addresses to replace as seen on the pcap file."],
                        ["PCAP_PLD_LIST", str(self.pcap_pld_list), "False", "Comma-separated list of packet payloads to replace as seen on the pcap file."],
                        ["PROTOCOL_LIST", str(self.proto_layer_list), "False", "Comma-separated list of protocol layers, which packet payload manipulation will apply to."],
                        ["REAL_TIME", str(self.real_time), "False", "Honor inter-packet arrival time while replaying traffic."],
                        ["WIRE_IP_LIST", str(self.wire_ip_list), "False", "Comma-separated list of IP addresses to replay as seen on the wire."],
                        ["WIRE_MAC_LIST", str(self.wire_mac_list), "False", "Comma-separated list of MAC addresses to replay as seen on the wire."],
                        ["WIRE_PLD_LIST", str(self.wire_pld_list), "False", "Comma-separated list of packet payloads to replay as seen on the wire."]]

        return self.options


    def validate_options(self):
        print("")
        return self.validate_mandatory_args(self.file, self.fragmentation, self.mtu, self.interface) and self.validate_optional_args(self.pcap_ip_list.split(","), self.wire_ip_list.split(","),
                                                                                                                   self.pcap_mac_list.split(","), self.wire_mac_list.split(","),
                                                                                                                   self.pcap_pld_list.split(","), self.proto_layer_list.split(","),
                                                                                                                   self.wire_pld_list.split(","), self.real_time) and self.check_optimal_replay_conditions(self.pcap_pld_list.split(","), self.wire_pld_list.split(","))


    def validate_mandatory_args(self, pcap_file, fragmentation, mtu_bytes, net_interface):
        valid_options = True

        base_path = "%s/%s" % (os.path.abspath(os.path.curdir), "pcaps")
        pcap_path = "%s/%s" % (base_path, pcap_file)
        is_valid_path = os.path.abspath(pcap_path).startswith(base_path)
        if not pcap_file or not is_valid_path or not libs.bt3in.check_file_exists(pcap_path):
            libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_PCAP)
            valid_options = False
        
        # Prevents an exception when parsing non-libpcap files in Ubuntu 16.04
        if pcap_file and is_valid_path and libs.bt3in.check_file_exists(pcap_path):
            with open(pcap_path, "rb") as pcap_file_magic:
               magic_number = pcap_file_magic.read(4)
               if str(magic_number).encode("hex").upper() not in ["D4C3B2A1", "A1B2C3D4"]:
                   libs.bt3out.print_error("A PCAP file in libpcap format must be provided.\n")
                   valid_options = False

        if type(fragmentation) != type(True):
            libs.bt3out.print_error("Fragmentation option value must be boolean (True or False).\n")
            valid_options = False

        try:
            mtu_bytes = int(mtu_bytes)
            if mtu_bytes < 1 or mtu_bytes > 9000:
                libs.bt3out.print_error("A valid MTU size must be provided.\n")
                valid_options = False

        except:
            libs.bt3out.print_error("A valid MTU size must be provided.\n")
            valid_options = False

        if not net_interface or not libs.bt3in.check_network_interface(net_interface):
            libs.bt3out.print_error("A valid network interface must be provided.\n")
            valid_options = False

        return valid_options


    def validate_optional_args(self, pcap_ip_addr_list, wire_ip_addr_list, pcap_mac_addr_list, wire_mac_addr_list, pcap_pld_list, proto_layer_list, wire_pld_list, real_time):
        valid_options = True
        if (pcap_ip_addr_list and not wire_ip_addr_list) or (wire_ip_addr_list and not pcap_ip_addr_list):
            libs.bt3out.print_error("Lists of matching pcap and wire IP addresses must be provided.\n")
            valid_options = False

        if (pcap_mac_addr_list and not wire_mac_addr_list) or (wire_mac_addr_list and not pcap_mac_addr_list):
            libs.bt3out.print_error("Lists of matching pcap and wire MAC addresses must be provided.\n")
            valid_options = False

        if pcap_ip_addr_list and wire_ip_addr_list:
            if len(pcap_ip_addr_list) != len(wire_ip_addr_list):
                libs.bt3out.print_error("Pcap and wire IP address lists must have the same number of elements.\n")
                valid_options = False

            elif len(pcap_ip_addr_list) == 1 and len(wire_ip_addr_list) == 1:
                if (pcap_ip_addr_list[0] and not wire_ip_addr_list[0]) or (not pcap_ip_addr_list[0] and wire_ip_addr_list[0]):
                    libs.bt3out.print_error("Pcap and wire IP address lists must have the same number of elements.\n")
                    valid_options = False

            for pcap_ip_addr in pcap_ip_addr_list:
                if pcap_ip_addr and not libs.bt3in.check_ip_address(pcap_ip_addr):
                    libs.bt3out.print_error("Pcap IP address \"%s\" is not valid.\n" % (pcap_ip_addr))
                    valid_options = False

            for wire_ip_addr in wire_ip_addr_list:
                if wire_ip_addr and not libs.bt3in.check_ip_address(wire_ip_addr):
                    libs.bt3out.print_error("Wire IP address \"%s\" is not valid.\n" % (wire_ip_addr))
                    valid_options = False

        if pcap_mac_addr_list and wire_mac_addr_list:
            if len(pcap_mac_addr_list) != len(wire_mac_addr_list):
                libs.bt3out.print_error("Pcap and wire MAC address lists must have the same number of elements.\n")
                valid_options = False

            elif len(pcap_mac_addr_list) == 1 and len(wire_mac_addr_list) == 1:
                if (pcap_mac_addr_list[0] and not wire_mac_addr_list[0]) or (not pcap_mac_addr_list[0] and wire_mac_addr_list[0]):
                    libs.bt3out.print_error("Pcap and wire MAC address lists must have the same number of elements.\n")
                    valid_options = False

            for pcap_mac_addr in pcap_mac_addr_list:
                if pcap_mac_addr and not libs.bt3in.check_mac_address(pcap_mac_addr):
                    libs.bt3out.print_error("Pcap MAC address \"%s\" is not valid.\n" % (pcap_mac_addr))
                    valid_options = False

            for wire_mac_addr in wire_mac_addr_list:
                if wire_mac_addr and not libs.bt3in.check_mac_address(wire_mac_addr):
                    libs.bt3out.print_error("Wire MAC address \"%s\" is not valid.\n" % (wire_mac_addr))
                    valid_options = False

        if proto_layer_list:
            for layer in proto_layer_list:
                if layer and layer not in self.proto_layer_support:
                    libs.bt3out.print_error("A valid protocol layer list must be provided. Current supported protocol layers are: DNS,NBNS,RAW,SMB.\n")
                    valid_options = False
                    break

        if pcap_pld_list and wire_pld_list:
            if len(pcap_pld_list) != len(wire_pld_list):
                libs.bt3out.print_error("Pcap and wire packet payload lists must have the same number of elements.\n")
                valid_options = False

            elif len(pcap_pld_list) == 1 and len(wire_pld_list) == 1:
                if (pcap_pld_list[0] and not wire_pld_list[0]) or (not pcap_pld_list[0] and wire_pld_list[0]):
                    libs.bt3out.print_error("Pcap and wire packet payload lists must have the same number of elements.\n")
                    valid_options = False

        if pcap_pld_list and wire_pld_list and proto_layer_list:
            if len(pcap_pld_list) >= 1 and len(wire_pld_list) >= 1 and len(proto_layer_list) == 1:
                if pcap_pld_list[0] and wire_pld_list[0] and not proto_layer_list[0]:
                    libs.bt3out.print_error("Pcap and wire packet payload lists are defined. However, no protocol layer list has been configured.\n")
                    libs.bt3out.print_info("You should provide a valid protocol layer list, if you want to use packet payload manipulation.")
                    libs.bt3out.print_info("Current supported protocol layers are: DNS,NBNS,RAW,SMB.\n")
                    valid_options = False

        if type(real_time) != type(True):
            libs.bt3out.print_error("Real time option value must be boolean (True or False).\n")
            valid_options = False

        return valid_options


    def check_optimal_replay_conditions(self, pcap_pld_list, wire_pld_list):
        optimal = True
        mismatch_list = []
        if pcap_pld_list and wire_pld_list:
            libs.bt3out.print_info("Checking packet payload manipulation parameters...")
            for pcap_pld, wire_pld in zip(pcap_pld_list, wire_pld_list):
                if len(pcap_pld) != len(wire_pld):
                    mismatch_list.append((pcap_pld, wire_pld))
                    optimal = False

        if not optimal:
            libs.bt3out.print_warning("The following packet payload manipulation parameters have a size mismatch:\n")
            for mismatch in mismatch_list:
                libs.bt3out.print_info("PCAP: %s -> WIRE: %s\t" % (mismatch[0], mismatch[1]))

            optimal = libs.bt3in.get_confirmation("%s\n" % libs.bt3out.NOT_OPTIMAL_REPLAY, "WARN")

        return optimal


class Menu(cmd.Cmd):

    def __init__(self):
        cmd.Cmd.__init__(self)
        self.api_credentials = []
        self.resource_cmds = []
        self.config = Options()
        self.pcapteller = Pcapteller()

        self.bytes_measure = 1048576.0
        self.description_length = 100
        self.pcap_folder = "./pcaps"
        libs.bt3out.setup_material_folder(self.pcap_folder)


    def clear_api_creds(self):
        if len(self.api_credentials) == 2:
            self.api_credentials[0] = libs.bt3api.generate_string()
            self.api_credentials[1] = libs.bt3api.generate_string()
            self.api_credentials    = []


    def complete_download(self, text, line, begidx, endidx):
        autocomplete_list = []

        if len(self.api_credentials) == 2 and line.startswith("download"):
            try:
                json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "pcap")
                if json_results and libs.bt3api.validate_json(json_results):
                    parsed_results = libs.bt3api.parse_json(json_results)
                    if parsed_results[-1]["Result"]:
                        del parsed_results[-1]
                        for pcap in parsed_results:
                            autocomplete_list.append(pcap["Name"])

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        return [i for i in autocomplete_list if i.startswith(text)]


    def complete_set(self, text, line, begidx, endidx):
        autocomplete_list = ["file", "FILE", "fragmentation", "FRAGMENTATION", "interface", "INTERFACE", "mtu", "MTU", "pcap_ip_list", "PCAP_IP_LIST",
                             "pcap_mac_list", "PCAP_MAC_LIST", "pcap_pld_list", "PCAP_PLD_LIST", "protocol_list", "PROTOCOL_LIST",
                             "real_time", "REAL_TIME", "wire_ip_list", "WIRE_IP_LIST", "wire_mac_list", "WIRE_MAC_LIST", "wire_pld_list", "WIRE_PLD_LIST" ]

        if line.startswith("set FILE") or line.startswith("set file"):
            try:
                pcap_folder = self.pcap_folder
                files = [f for f in os.listdir(pcap_folder) if os.path.isfile(os.path.join(pcap_folder, f))]
                files.sort()
                for pcap in files:
                    if pcap.endswith(".pcap") or pcap.endswith(".cap"):
                        pcap_name = pcap
                        autocomplete_list.append(pcap_name)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        elif line.startswith("set FRAGMENTATION") or line.startswith("set fragmentation") or line.startswith("set REAL_TIME") or line.startswith("set real_time"):
            autocomplete_list.append("True")
            autocomplete_list.append("true")
            autocomplete_list.append("False")
            autocomplete_list.append("false")

        return [i for i in autocomplete_list if i.startswith(text)]


    def complete_show(self, text, line, begidx, endidx):
        autocomplete_list = ["options", "pcaps", "interfaces"]
        if line.startswith("show pcaps"):
            autocomplete_list.append("cloud")
            autocomplete_list.append("disk")

        return [i for i in autocomplete_list if i.startswith(text)]


    def default(self, args):
        print("")
        libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_COMMAND)


    def do_download(self, args):
        if len(self.api_credentials) == 2:
            if libs.bt3in.get_confirmation("%s" % libs.bt3out.MATERIAL_DOWNLOAD, "WARN"):
                args = args.split(" ")
                if len(args) == 1 and args[0] not in [""]:
                    try:
                        libs.bt3out.print_info("Downloading...")
                        json_results = libs.bt3api.download_material(self.api_credentials[0], self.api_credentials[1],
                                                                     "pcap", args[0], self.pcap_folder)
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if not parsed_results[-1]["Result"]:
                                libs.bt3out.print_error("%s\n" % parsed_results[-1]["Msg"])
                                libs.bt3out.log_download("pcap", args[0], "ERROR")

                        else:
                            zip_file_path = "%s/%s.zip" % (self.pcap_folder, os.path.basename(args[0]))
                            if libs.bt3in.check_file_exists(zip_file_path) and zipfile.is_zipfile(zip_file_path):
                                zip_file = zipfile.ZipFile(zip_file_path, "r")
                                zip_file.extractall(self.pcap_folder)
                                zip_file.close()
                                os.remove(zip_file_path)
                                libs.bt3out.print_ok("%s\n" % libs.bt3out.MATERIAL_INSTALLED)
                                libs.bt3out.print_warning("%s" % libs.bt3out.MALWARE_FILES)
                                libs.bt3out.print_warning("%s\n" % libs.bt3out.WARNING_EXPORT_OBJ)
                                libs.bt3out.log_download("pcap", args[0], "SUCCESS")

                            else:
                                libs.bt3out.print_error("%s" % libs.bt3out.MATERIAL_DAMAGED)
                                libs.bt3out.log_download("pcap", args[0], "ERROR")

                        # Display credit balance
                        json_results = libs.bt3api.get_subscription(self.api_credentials[0], self.api_credentials[1])
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if parsed_results[-1]["Result"]:
                                del parsed_results[-1]
                                for subscription in parsed_results:
                                    libs.bt3out.print_info("Your current balance is %s credit(s).\n" % subscription["CreditBalance"])

                            else:
                                print("")
                                libs.bt3out.print_error("%s\n" % parsed_results[-1]["Msg"])

                        else:
                            print("")
                            libs.bt3out.print_error("Could not retrieve your current balance.\n")

                    except Exception as e:
                        print("")
                        libs.bt3out.print_error("%s\n" % e)

        else:
            print("")
            libs.bt3out.print_error("%s\n" % libs.bt3out.API_AUTHENTICATION)


    def emptyline(self):
        pass


    def do_back(self, args):
        return True


    def do_exit(self, args):
        self.clear_api_creds()
        libs.bt3out.exit_program(args)


    def do_help(self, args):
        cmds = [["back", "Exit current selected module and return to main menu."],
                ["download <pcap>", "Download a given PCAP file from the Blue Team Training Toolkit cloud."],
                ["exit", "Exit the Blue Team Training Toolkit."],
                ["help", "Display help menu."],
                ["run", "Run the module with the given options."],
                ["search <string>", "Find PCAP files based on a given string."],
                ["set <option> <value>", "Set module option."],
                ["show interfaces", "Display available network interfaces."],
                ["show options", "Display module options."],
                ["show pcaps", "Display all available PCAP files."],
                ["show pcaps cloud", "Display PCAP files available in the cloud."],
                ["show pcaps disk", "Display PCAP files available on your computer."],
                ["version", "Display module version."]]
        libs.bt3out.print_help(cmds, False, True)


    def preloop(self):
        if len(self.resource_cmds) > 0:
            for cmd in self.resource_cmds:
                c = self.precmd(cmd)
                e = self.onecmd(c)

            self.resource_cmds = []


    def do_set(self, args):
        try:
            args = args.split(" ")
            option_set = False
            if len(args) == 2:
                if args[0].upper() in ["FILE"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.file = ""
                    else:
                        self.config.file = os.path.basename(args[1])
                    
                    option_set = True

                elif args[0].upper() in ["FRAGMENTATION"]:
                    if args[1].upper() in ["TRUE"]:
                        self.config.fragmentation = True
                    else:
                        self.config.fragmentation = False

                    option_set = True

                elif args[0].upper() in ["INTERFACE"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.interface = ""
                    else:
                        self.config.interface = args[1]
                    
                    option_set = True

                elif args[0].upper() in ["MTU"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.mtu = ""
                    else:
                        self.config.mtu = args[1]
                    
                    option_set = True

                elif args[0].upper() in ["PCAP_IP_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.pcap_ip_list = ""
                    else:
                        self.config.pcap_ip_list = args[1]

                    option_set = True

                elif args[0].upper() in ["PCAP_MAC_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.pcap_mac_list = ""
                    else:
                        self.config.pcap_mac_list = args[1]

                    option_set = True

                elif args[0].upper() in ["PCAP_PLD_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.pcap_pld_list = ""
                    else:
                        self.config.pcap_pld_list = args[1]

                    option_set = True

                elif args[0].upper() in ["PROTOCOL_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.proto_layer_list = ""
                    else:
                        self.config.proto_layer_list = args[1].upper()

                    option_set = True

                elif args[0].upper() in ["REAL_TIME"]:
                    if args[1].upper() in ["TRUE"]:
                        self.config.real_time = True
                    else:
                        self.config.real_time = False

                    option_set = True

                elif args[0].upper() in ["WIRE_IP_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.wire_ip_list = ""
                    else:
                        self.config.wire_ip_list = args[1]

                    option_set = True

                elif args[0].upper() in ["WIRE_MAC_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.wire_mac_list = ""
                    else:
                        self.config.wire_mac_list = args[1]

                    option_set = True

                elif args[0].upper() in ["WIRE_PLD_LIST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.wire_pld_list = ""
                    else:
                        self.config.wire_pld_list = args[1]

                    option_set = True

            if option_set:
                print("")
                if args[0] in ["FILE"]:
                    libs.bt3out.print_ok("%s => %s\n" % (args[0], os.path.basename(args[1])))
                else:
                    libs.bt3out.print_ok("%s => %s\n" % (args[0], args[1]))

            else:
                cmds = [["set FILE <file name>", "Set a PCAP file to replay in libpcap format."],
                        ["set FRAGMENTATION <bool>", "Set whether packets should be fragmented during replay. Useful for networks with low MTU."],
                        ["set INTERFACE <net iface>", "Set a network interface to replay the packets with."],
                        ["set MTU <int>", "Set the packet fragmentation MTU size."],
                        ["set PCAP_IP_LIST <ip addr>", "Set a comma-separated list of IP addresses to replace as seen on the PCAP file."],
                        ["set PCAP_MAC_LIST <mac addr>", "Set a comma-separated list of MAC addresses to replace as seen on the PCAP file."],
                        ["set PCAP_PLD_LIST <string>", "Set a comma-separated list of packet payloads to replace as seen on the PCAP file."],
                        ["set PROTOCOL_LIST <string>", "Set a comma-separated list of protocol layers, which packet payload manipulation will apply to."],
                        ["set REAL_TIME <bool>", "Set whether inter-packet arrival time should be honored while replaying traffic."],
                        ["set WIRE_IP_LIST <ip addr>", "Set a comma-separated list of IP addresses to replay as seen on the wire."],
                        ["set WIRE_MAC_LIST <mac addr>", "Set a comma-separated list of MAC addresses to replay as seen on the wire."],
                        ["set WIRE_PLD_LIST <string>", "Set a comma-separated list of packet payloads to replay as seen on the wire."]]
                libs.bt3out.print_help(cmds, True, True)

        except Exception as e:
            print("")
            libs.bt3out.print_error("%s\n" % e)


    def do_search(self, args):
        args = args.split(" ")
        if len(args) == 1 and args[0] not in [""]:
            try:
                pcap_folder = self.pcap_folder
                files = [f for f in os.listdir(pcap_folder) if os.path.isfile(os.path.join(pcap_folder, f))]
                files.sort()
                result = []
                for pcap in files:
                    if pcap.endswith(".pcap") or pcap.endswith(".cap"):
                        pcap_name = pcap
                        pcap_size = os.path.getsize("%s/%s" % (pcap_folder, os.path.basename(pcap_name)))
                        pcap_location = "Disk"
                        pcap_date = "####-##-##"
                        pcap_description = libs.bt3out.NO_DESCRIPTION

                        pcap_module_file = "%s.py" % pcap.replace(".pcap", "").replace(".cap", "")
                        if pcap_module_file not in ["__init__.py"] and libs.bt3in.check_file_exists("%s/%s" % (pcap_folder, os.path.basename(pcap_module_file))):
                            loaded_pcap = self.pcapteller.load_info(pcap_module_file.replace(".py", ""))
                            pcap_date = loaded_pcap.info.date
                            if len(pcap_description) > 0:
                                pcap_description = loaded_pcap.info.description

                        if pcap_name.find(args[0]) > -1 or pcap_description.find(args[0]) > -1:
                            result.append([ pcap_name, str(round(pcap_size / self.bytes_measure, 3)), pcap_location, pcap_date, " ", pcap_description.replace("\n", "")[:self.description_length] ])

                #API INTEGRATION - START
                if len(self.api_credentials) == 2:
                    json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "pcap")
                    if json_results and libs.bt3api.validate_json(json_results):
                        parsed_results = libs.bt3api.parse_json(json_results)
                        if parsed_results[-1]["Result"]:
                            del parsed_results[-1]
                            for pcap in parsed_results:
                                if pcap["Name"].find(args[0]) > -1 or pcap["Description"].find(args[0]) > -1:
                                    result.append([ pcap["Name"],  pcap["Size"], "Cloud", pcap["Date"], pcap["Price"], pcap["Description"].replace("\n", "") ])

                        else:
                            print("")
                            libs.bt3out.print_warning("%s\n" % parsed_results[-1]["Msg"])
                    else:
                        print("")
                        libs.bt3out.print_error("%s" % libs.bt3out.API_INCOMMUNICATION)
                        libs.bt3out.print_error("%s\n" % libs.bt3out.CONTACT_SUPPORT)

                #API INTEGRATION - END

                if len(result) > 0:
                    libs.bt3out.print_pcaps(result)
                    print("")
                    libs.bt3out.print_info("Search results: %s\n" % len(result))
                    libs.bt3out.print_warning("%s" % libs.bt3out.MALWARE_FILES)
                    libs.bt3out.print_warning("%s\n" % libs.bt3out.WARNING_EXPORT_OBJ)

                else:
                    print("")
                    libs.bt3out.print_info("%s\n" % libs.bt3out.NO_RESULTS)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        else:
            cmds = [["search <string>", "Find PCAP files based on a given string."]]
            libs.bt3out.print_help(cmds, True, True)


    def do_show(self, args):
        if args.upper() in ["INTERFACES"]:
            libs.bt3out.print_interfaces()

        elif args.upper() in ["OPTIONS"]:
            libs.bt3out.print_options(self.config.get_options())

        elif args.upper() in ["PCAPS", "PCAPS CLOUD", "PCAPS DISK"]:
            try:
                pcap_folder = self.pcap_folder
                files = [f for f in os.listdir(pcap_folder) if os.path.isfile(os.path.join(pcap_folder, f))]
                files.sort()
                result = []

                if args.upper() in ["PCAPS", "PCAPS DISK"]:
                    for pcap in files:
                        if pcap.endswith(".pcap") or pcap.endswith(".cap"):
                            pcap_name = pcap
                            pcap_size = os.path.getsize("%s/%s" % (pcap_folder, os.path.basename(pcap_name)))
                            pcap_location = "Disk"
                            pcap_date = "####-##-##"
                            pcap_description = libs.bt3out.NO_DESCRIPTION

                            pcap_module_file = "%s.py" % pcap.replace(".pcap", "").replace(".cap", "")
                            if pcap_module_file not in ["__init__.py"] and libs.bt3in.check_file_exists("%s/%s" % (pcap_folder, os.path.basename(pcap_module_file))):
                                loaded_pcap = self.pcapteller.load_info(pcap_module_file.replace(".py", ""))
                                pcap_date = loaded_pcap.info.date
                                if len(pcap_description) > 0:
                                    pcap_description = loaded_pcap.info.description

                            result.append([ pcap_name, str(round(pcap_size / self.bytes_measure, 3)), pcap_location, pcap_date, " ", pcap_description.replace("\n", "")[:self.description_length] ])

                #API INTEGRATION - START
                if args.upper() in ["PCAPS", "PCAPS CLOUD"]:
                    if len(self.api_credentials) == 2:
                        json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "pcap")
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if parsed_results[-1]["Result"]:
                                del parsed_results[-1]
                                for pcap in parsed_results:
                                    result.append([ pcap["Name"], pcap["Size"], "Cloud", pcap["Date"], pcap["Price"], pcap["Description"].replace("\n", "") ])

                            else:
                                print("")
                                libs.bt3out.print_warning("%s\n" % parsed_results[-1]["Msg"])
                        else:
                            print("")
                            libs.bt3out.print_error("%s" % libs.bt3out.API_INCOMMUNICATION)
                            libs.bt3out.print_error("%s\n" % libs.bt3out.CONTACT_SUPPORT)

                #API INTEGRATION - END

                if len(result) > 0:
                    libs.bt3out.print_pcaps(result)
                    print("")
                    libs.bt3out.print_info("Available PCAP files: %s\n" % len(result))
                    libs.bt3out.print_warning("%s" % libs.bt3out.MALWARE_FILES)
                    libs.bt3out.print_warning("%s\n" % libs.bt3out.WARNING_EXPORT_OBJ)

                else:
                    print("")
                    libs.bt3out.print_info("No PCAP files were found.")
                    libs.bt3out.print_warning("%s\n" % libs.bt3out.API_JOIN_COMMUNITY)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)


        else:
            cmds = [["show options", "Display module options."],
                    ["show pcaps", "Display all available PCAP files."],
                    ["show pcaps cloud", "Display PCAP files available in the cloud."],
                    ["show pcaps disk", "Display PCAP files available on your computer."]]
            libs.bt3out.print_help(cmds, True, True)


    def do_run(self, args):
        if self.config.validate_options():
            base_path = "%s/%s" % (os.path.abspath(os.path.curdir), "pcaps")
            pcap_path = "%s/%s" % (base_path, self.config.file)
            self.pcapteller.run(pcap_path, self.config.fragmentation, self.config.mtu, self.config.interface, self.config.pcap_ip_list.split(","),
                                self.config.wire_ip_list.split(","), self.config.pcap_mac_list.split(","), self.config.wire_mac_list.split(","),
                                self.config.pcap_pld_list.split(","), self.config.proto_layer_list.split(","), self.config.wire_pld_list.split(","), self.config.real_time)


    def do_version(self, args):
        print("")
        libs.bt3out.print_info("You are running %s version %s\n" % (__module_name__, __module_version__))



class Pcapteller():

    def load_info(self, pcap):
        pcap_module = importlib.import_module("pcaps.%s" % pcap)
        pcap_module = reload(pcap_module)

        return pcap_module.Pcap()


    def read_traffic(self, pcap_file):
        return rdpcap(pcap_file)


    def traffic_manipulation(self, pcap_file, total_packets, pcap_ip_addr_list, wire_ip_addr_list, pcap_mac_addr_list, wire_mac_addr_list, pcap_pld_list, proto_layer_list, wire_pld_list):
        packet_counter = 0
        error_counter = 0
        packets = []
        for packet in pcap_file:
            try:
                packet_counter += 1
                sys.stdout.write("\r\033[1;34m[*]\033[1;m Processing %s of %s packet(s) | Error: %s packet(s)." % (packet_counter, total_packets, error_counter))
                sys.stdout.flush()

                if packet.haslayer(Ether):
                    if pcap_mac_addr_list and wire_mac_addr_list:
                        for pcap_mac_addr, wire_mac_addr in zip(pcap_mac_addr_list, wire_mac_addr_list):
                            if packet[Ether].src == pcap_mac_addr:
                                packet[Ether].src = wire_mac_addr

                            if packet[Ether].dst == pcap_mac_addr:
                                packet[Ether].dst = wire_mac_addr

                if packet.haslayer(UDP):
                    del(packet[UDP].chksum)
                    del(packet[UDP].len)

                if packet.haslayer(ICMP):
                    del(packet[ICMP].chksum)

                if packet.haslayer(TCP):
                    del(packet[TCP].chksum)

                if packet.haslayer(IP):
                    del(packet[IP].chksum)
                    del(packet[IP].len)
                    if pcap_ip_addr_list and wire_ip_addr_list:
                        for pcap_ip_addr, wire_ip_addr in zip(pcap_ip_addr_list, wire_ip_addr_list):
                            if packet[IP].src == pcap_ip_addr:
                                packet[IP].src = wire_ip_addr

                            if packet[IP].dst == pcap_ip_addr:
                                packet[IP].dst = wire_ip_addr

                # DNS packet payload manipulation.
                if "DNS" in proto_layer_list and packet.haslayer(DNS):
                    if pcap_pld_list and wire_pld_list:
                        for pcap_pld, wire_pld in zip(pcap_pld_list, wire_pld_list):
                            if packet[DNS].haslayer(DNSQR):
                                for index in range(packet[DNS].qdcount):
                                    if str(packet[DNS].qd[index].qname).find(pcap_pld) > -1:
                                        packet[DNS].qd[index].qname = str(packet[DNS].qd[index].qname).replace(pcap_pld, wire_pld)

                            if packet[DNS].haslayer(DNSRR):
                                for index in range(packet[DNS].ancount):
                                    del(packet[DNS].an[index].rdlen)
                                    if str(packet[DNS].an[index].rrname).find(pcap_pld) > -1: 
                                        packet[DNS].an[index].rrname = str(packet[DNS].an[index].rrname).replace(pcap_pld, wire_pld)
                                    
                                    if str(packet[DNS].an[index].rdata).find(pcap_pld) > -1:
                                        packet[DNS].an[index].rdata = str(packet[DNS].an[index].rdata).replace(pcap_pld, wire_pld)

                # RAW packet payload manipulation. Applies to UDP, HTTP, ICMP and others.
                if "RAW" in proto_layer_list and packet.haslayer(Raw):
                    if pcap_pld_list and wire_pld_list:
                        for pcap_pld, wire_pld in zip(pcap_pld_list, wire_pld_list):
                            
                            if str(packet[Raw].load).find(pcap_pld) > -1:
                                packet[Raw].load = str(packet[Raw].load).replace(pcap_pld, wire_pld)
                                
                # NBNS packet payload manipulation. Special case of RAW packet payload manipulation.
                if "NBNS" in proto_layer_list and packet.haslayer(NBNSQueryRequest):
                    if pcap_pld_list and wire_pld_list:
                        for pcap_pld, wire_pld in zip(pcap_pld_list, wire_pld_list):
                            
                            if packet[NBNSQueryRequest].QUESTION_NAME.find(pcap_pld) > -1:
                                packet[NBNSQueryRequest].QUESTION_NAME = str(packet[NBNSQueryRequest].QUESTION_NAME).replace(pcap_pld, wire_pld)
                
                # NBNS packet payload manipulation. Special case of RAW packet payload manipulation.
                if "NBNS" in proto_layer_list and packet.haslayer(Raw):
                    if pcap_pld_list and wire_pld_list:
                        for pcap_pld, wire_pld in zip(pcap_pld_list, wire_pld_list):
                            
                            payload_hex = packet[Raw].load.encode("hex")
                            
                            if libs.bt3in.check_ip_address(pcap_pld) and libs.bt3in.check_ip_address(wire_pld):
                                pcap_pld_hex_ip = str(socket.inet_aton(pcap_pld)).encode("hex")
                                wire_pld_hex_ip = str(socket.inet_aton(wire_pld)).encode("hex")
                                
                                if payload_hex.find(pcap_pld_hex_ip) > -1:
                                    payload_hex = payload_hex.replace(pcap_pld_hex_ip, wire_pld_hex_ip)
                                
                                packet[Raw].load = payload_hex.decode("hex")
                                
                # SMB packet payload manipulation. Special case of RAW packet payload manipulation.
                if "SMB" in proto_layer_list and packet.haslayer(Raw):
                    if pcap_pld_list and wire_pld_list:
                        for pcap_pld, wire_pld in zip(pcap_pld_list, wire_pld_list):
                            
                            pcap_pld_hex = pcap_pld.encode("hex")
                            wire_pld_hex = wire_pld.encode("hex")
                            pcap_pld_hex_upper = pcap_pld.upper().encode("hex")
                            wire_pld_hex_upper = wire_pld.upper().encode("hex")
                            
                            pcap_pld_pad = ""
                            wire_pld_pad = ""
                            pcap_pld_pad_upper = ""
                            wire_pld_pad_upper = ""
                            
                            pcap_pld_pad_reverse = ""
                            wire_pld_pad_reverse = ""
                            pcap_pld_pad_reverse_upper = ""
                            wire_pld_pad_reverse_upper = ""
                            
                            for p_char in pcap_pld:
                                pcap_pld_pad += "00%s" % p_char.encode("hex")
                                pcap_pld_pad_upper += "00%s" % p_char.upper().encode("hex")
                                pcap_pld_pad_reverse += "%s00" % p_char.encode("hex")
                                pcap_pld_pad_reverse_upper += "%s00" % p_char.upper().encode("hex")
                            
                            for w_char in wire_pld:
                                wire_pld_pad += "00%s" % w_char.encode("hex")
                                wire_pld_pad_upper += "00%s" % w_char.upper().encode("hex")
                                wire_pld_pad_reverse += "%s00" % w_char.encode("hex")
                                wire_pld_pad_reverse_upper += "%s00" % w_char.upper().encode("hex")
                            
                            payload_hex = packet[Raw].load.encode("hex")
                            
                            if payload_hex.find(pcap_pld_hex) > -1:
                                payload_hex = payload_hex.replace(pcap_pld_hex, wire_pld_hex)
                            
                            if payload_hex.find(pcap_pld_hex_upper) > -1:
                                payload_hex = payload_hex.replace(pcap_pld_hex_upper, wire_pld_hex_upper)
                            
                            if payload_hex.find(pcap_pld_pad) > -1:
                                payload_hex = payload_hex.replace(pcap_pld_pad, wire_pld_pad)
                                
                            if payload_hex.find(pcap_pld_pad_upper) > -1:
                                payload_hex = payload_hex.replace(pcap_pld_pad_upper, wire_pld_pad_upper)
                                
                            if payload_hex.find(pcap_pld_pad_reverse) > -1:
                                payload_hex = payload_hex.replace(pcap_pld_pad_reverse, wire_pld_pad_reverse)
                                
                            if payload_hex.find(pcap_pld_pad_reverse_upper) > -1:
                                payload_hex = payload_hex.replace(pcap_pld_pad_reverse_upper, wire_pld_pad_reverse_upper)
                            
                            packet[Raw].load = payload_hex.decode("hex")

                packets.append(packet)

            except:
                error_counter += 1

        return packets


    def traffic_replay(self, packets, net_interface, real_time, fragmentation, mtu_bytes):
        error = False
        try:
            if fragmentation:
                sendp(fragment(packets, int(mtu_bytes)), iface=net_interface, verbose=0, realtime=real_time)
            else:
                sendp(packets, iface=net_interface, verbose=0, realtime=real_time)

        except:
            error = True

        return error


    def run(self, pcap_file, fragmentation, mtu_bytes, net_interface, pcap_ip_addr_list, wire_ip_addr_list, pcap_mac_addr_list, wire_mac_addr_list, pcap_pld_list, proto_layer_list, wire_pld_list, real_time):

        try:
            signal.signal(signal.SIGINT, libs.bt3in.allow_keyboard_interrupt)
            libs.bt3out.print_info("Pcapteller started at %s. Press [CTRL+C] to stop.\n" % (datetime.now().strftime("%H:%M:%S")))
            libs.bt3out.print_info("Reading \"%s\"..." % (pcap_file))
            pf = self.read_traffic(pcap_file)
            total_packets = len(pf)
            libs.bt3out.print_ok("%s packet(s) found.\n" % (total_packets))

            # Traffic manipulation
            packets = self.traffic_manipulation(pf, total_packets, pcap_ip_addr_list, wire_ip_addr_list, pcap_mac_addr_list, wire_mac_addr_list, pcap_pld_list, proto_layer_list, wire_pld_list)
            print("")

            # Traffic replay
            if fragmentation:
                libs.bt3out.print_warning("Packet fragmentation enabled. MTU size will be set to %s bytes..." % str(mtu_bytes))

            if real_time:
                libs.bt3out.print_warning("Real time enabled. Replay speed will be determined by the actual PCAP file...")

            libs.bt3out.print_info("Replaying packet(s) via %s..." % (net_interface))
            error = self.traffic_replay(packets, net_interface, real_time, fragmentation, mtu_bytes)

            if error:
                libs.bt3out.print_error("Replay incomplete. Packets were injected, but an error ocurred during the replay.\n")
                libs.bt3out.print_warning("Tips: Try enabling or disabling packet fragmentation.")
                libs.bt3out.print_warning("      Try packet fragmentation with different MTU values (e.g. 1024 bytes).\n")

            else:
                libs.bt3out.print_ok("Replay complete.\n")

            libs.bt3out.print_info("Pcapteller finished at %s.\n" % (datetime.now().strftime("%H:%M:%S")))
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)

        except KeyboardInterrupt:
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)
            return True

        except Exception as e:
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)
            libs.bt3out.print_error("%s.\n" % (e))
            return True

