#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import cmd, os
import importlib, zipfile
import libs.bt3out, libs.bt3in, libs.bt3api


__module_name__    = "Mocksum"
__module_version__ = "1.2"


class Options():

    def __init__(self):
        self.options = ""

    def get_options(self):
        self.options = [["DUMMY", str(" "), "False", "Dummy option"]]

        return self.options


    def validate_options(self):
        print("")
        return self.validate_mandatory_args() and self.validate_optional_args()


    def validate_mandatory_args(self):
        valid_options = True
        return valid_options


    def validate_optional_args(self):
        valid_options = True
        return valid_options



class Menu(cmd.Cmd):

    def __init__(self):
        cmd.Cmd.__init__(self)
        self.api_credentials = []
        self.resource_cmds = []
        self.config = Options()
        self.mocksum = Mocksum()
        self.bytes_measure = 1048576.0
        self.description_length = 100
        self.mock_folder = "./mockfiles"
        libs.bt3out.setup_material_folder(self.mock_folder)


    def clear_api_creds(self):
        if len(self.api_credentials) == 2:
            self.api_credentials[0] = libs.bt3api.generate_string()
            self.api_credentials[1] = libs.bt3api.generate_string()
            self.api_credentials    = []


    def complete_download(self, text, line, begidx, endidx):
        autocomplete_list = []

        if len(self.api_credentials) == 2 and line.startswith("download"):
            try:
                json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "mockfile")
                if json_results and libs.bt3api.validate_json(json_results):
                    parsed_results = libs.bt3api.parse_json(json_results)
                    if parsed_results[-1]["Result"]:
                        del parsed_results[-1]
                        for mockfile in parsed_results:
                            autocomplete_list.append(mockfile["Name"])

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        return [i for i in autocomplete_list if i.startswith(text)]


    def complete_show(self, text, line, begidx, endidx):
        autocomplete_list = ["mockfiles", "options"]
        if line.startswith("show mockfiles"):
            autocomplete_list.append("cloud")
            autocomplete_list.append("disk")

        return [i for i in autocomplete_list if i.startswith(text)]


    def default(self, args):
        print("")
        libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_COMMAND)


    def do_download(self, args):
        if len(self.api_credentials) == 2:
            if libs.bt3in.get_confirmation("%s" % libs.bt3out.MATERIAL_DOWNLOAD, "WARN"):
                args = args.split(" ")
                if len(args) == 1 and args[0] not in [""]:
                    try:
                        libs.bt3out.print_info("Downloading...")
                        json_results = libs.bt3api.download_material(self.api_credentials[0], self.api_credentials[1],
                                                                     "mockfile", args[0], self.mock_folder)
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if not parsed_results[-1]["Result"]:
                                libs.bt3out.print_error("%s\n" % parsed_results[-1]["Msg"])
                                libs.bt3out.log_download("mockfile", args[0], "ERROR")

                        else:
                            zip_file_path = "%s/%s.zip" % (self.mock_folder, os.path.basename(args[0]))
                            if libs.bt3in.check_file_exists(zip_file_path) and zipfile.is_zipfile(zip_file_path):
                                zip_file = zipfile.ZipFile(zip_file_path, "r")
                                zip_file.extractall(self.mock_folder)
                                zip_file.close()
                                os.remove(zip_file_path)
                                libs.bt3out.print_ok("%s\n" % libs.bt3out.MATERIAL_INSTALLED)
                                libs.bt3out.log_download("mockfile", args[0], "SUCCESS")

                            else:
                                libs.bt3out.print_error("%s" % libs.bt3out.MATERIAL_DAMAGED)
                                libs.bt3out.log_download("mockfile", args[0], "ERROR")

                        # Display credit balance
                        json_results = libs.bt3api.get_subscription(self.api_credentials[0], self.api_credentials[1])
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if parsed_results[-1]["Result"]:
                                del parsed_results[-1]
                                for subscription in parsed_results:
                                    libs.bt3out.print_info("Your current balance is %s credit(s).\n" % subscription["CreditBalance"])

                            else:
                                print("")
                                libs.bt3out.print_error("%s\n" % parsed_results[-1]["Msg"])

                        else:
                            print("")
                            libs.bt3out.print_error("Could not retrieve your current balance.\n")

                    except Exception as e:
                        print("")
                        libs.bt3out.print_error("%s\n" % e)

        else:
            print("")
            libs.bt3out.print_error("%s\n" % libs.bt3out.API_AUTHENTICATION)


    def emptyline(self):
        pass


    def do_back(self, args):
        return True


    def do_exit(self, args):
        self.clear_api_creds()
        libs.bt3out.exit_program(args)


    def do_help(self, args):
        cmds = [["back", "Exit current selected module and return to main menu."],
                ["download <mockfile>", "Download a given mock file from the Blue Team Training Toolkit cloud."],
                ["exit", "Exit the Blue Team Training Toolkit."],
                ["help", "Display help menu."],
                ["run", "Run the module with the given options."],
                ["search <string>", "Find mock files based on a given string."],
                ["show mockfiles", "Display all available mock files."],
                ["show mockfiles cloud", "Display mock files available in the cloud."],
                ["show mockfiles disk", "Display mock files available on your computer."],
                ["show options", "Display module options."],
                ["version", "Display module version."]]
        libs.bt3out.print_help(cmds, False, True)


    def preloop(self):
        if len(self.resource_cmds) > 0:
            for cmd in self.resource_cmds:
                c = self.precmd(cmd)
                e = self.onecmd(c)

            self.resource_cmds = []


    def do_run(self, args):
        print("")
        libs.bt3out.print_error("%s\n" % libs.bt3out.NO_RUN_COMMAND)


    def do_search(self, args):
        args = args.split(" ")
        if len(args) == 1 and args[0] not in [""]:
            try:
                mock_folder = self.mock_folder
                files = [f for f in os.listdir(mock_folder) if os.path.isfile(os.path.join(mock_folder, f))]
                files.sort()
                result = []
                for mockfile in files:
                    if mockfile.endswith(".mock"):
                        mockfile_name = mockfile
                        mockfile_size = os.path.getsize("%s/%s" % (mock_folder, os.path.basename(mockfile_name)))
                        mockfile_location = "Disk"
                        mockfile_date = "####-##-##"
                        mockfile_description = libs.bt3out.NO_DESCRIPTION

                        mockfile_module_file = "%s.py" % mockfile.replace(".mock", "")
                        if mockfile_module_file not in ["__init__.py"] and libs.bt3in.check_file_exists("%s/%s" % (mock_folder, os.path.basename(mockfile_module_file))):
                            loaded_mockfile = self.mocksum.load_info(mockfile_module_file.replace(".py", ""))
                            mockfile_date = loaded_mockfile.info.date
                            if len(mockfile_description) > 0:
                                mockfile_description = loaded_mockfile.info.description

                        if mockfile_name.find(args[0]) > -1 or mockfile_description.find(args[0]) > -1:
                            result.append([ mockfile_name, str(round(mockfile_size / self.bytes_measure, 3)), mockfile_location, mockfile_date, " ", mockfile_description.replace("\n", "")[:self.description_length] ])

                #API INTEGRATION - START
                if len(self.api_credentials) == 2:
                    json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "mockfile")
                    if json_results and libs.bt3api.validate_json(json_results):
                        parsed_results = libs.bt3api.parse_json(json_results)
                        if parsed_results[-1]["Result"]:
                            del parsed_results[-1]
                            for mockfile in parsed_results:
                                if mockfile["Name"].find(args[0]) > -1 or mockfile["Description"].find(args[0]) > -1:
                                    result.append([ mockfile["Name"],  mockfile["Size"], "Cloud", mockfile["Date"], mockfile["Price"], mockfile["Description"].replace("\n", "") ])

                        else:
                            print("")
                            libs.bt3out.print_warning("%s\n" % parsed_results[-1]["Msg"])
                    else:
                        print("")
                        libs.bt3out.print_error("%s" % libs.bt3out.API_INCOMMUNICATION)
                        libs.bt3out.print_error("%s\n" % libs.bt3out.CONTACT_SUPPORT)

                #API INTEGRATION - END

                if len(result) > 0:
                    libs.bt3out.print_mockfiles(result)
                    print("")
                    libs.bt3out.print_info("Search results: %s\n" % len(result))

                else:
                    print("")
                    libs.bt3out.print_info("%s\n" % libs.bt3out.NO_RESULTS)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        else:
            cmds = [["search <string>", "Find mock files based on a given string."]]
            libs.bt3out.print_help(cmds, True, True)


    def do_show(self, args):
        if args.upper() in ["OPTIONS"]:
            print("")
            libs.bt3out.print_info("%s\n" % libs.bt3out.NO_OPTIONS)

        elif args.upper() in ["MOCKFILES", "MOCKFILES CLOUD", "MOCKFILES DISK"]:
            try:
                mock_folder = self.mock_folder
                files = [f for f in os.listdir(mock_folder) if os.path.isfile(os.path.join(mock_folder, f))]
                files.sort()
                result = []

                if args.upper() in ["MOCKFILES", "MOCKFILES DISK"]:
                    for mockfile in files:
                        if mockfile.endswith(".mock"):
                            mockfile_name = mockfile
                            mockfile_size = os.path.getsize("%s/%s" % (mock_folder, os.path.basename(mockfile_name)))
                            mockfile_location = "Disk"
                            mockfile_date = "####-##-##"
                            mockfile_description = libs.bt3out.NO_DESCRIPTION

                            mockfile_module_file = "%s.py" % mockfile.replace(".mock", "")
                            if mockfile_module_file not in ["__init__.py"] and libs.bt3in.check_file_exists("%s/%s" % (mock_folder, os.path.basename(mockfile_module_file))):
                                loaded_mockfile = self.mocksum.load_info(mockfile_module_file.replace(".py", ""))
                                mockfile_date = loaded_mockfile.info.date
                                if len(mockfile_description) > 0:
                                    mockfile_description = loaded_mockfile.info.description

                            result.append([ mockfile_name, str(round(mockfile_size / self.bytes_measure, 3)), mockfile_location, mockfile_date, " ", mockfile_description.replace("\n", "")[:self.description_length] ])

                #API INTEGRATION - START
                if args.upper() in ["MOCKFILES", "MOCKFILES CLOUD"]:
                    if len(self.api_credentials) == 2:
                        json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "mockfile")
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if parsed_results[-1]["Result"]:
                                del parsed_results[-1]
                                for mockfile in parsed_results:
                                    result.append([ mockfile["Name"], mockfile["Size"], "Cloud", mockfile["Date"], mockfile["Price"], mockfile["Description"].replace("\n", "") ])

                            else:
                                print("")
                                libs.bt3out.print_warning("%s\n" % parsed_results[-1]["Msg"])
                        else:
                            print("")
                            libs.bt3out.print_error("%s" % libs.bt3out.API_INCOMMUNICATION)
                            libs.bt3out.print_error("%s\n" % libs.bt3out.CONTACT_SUPPORT)

                #API INTEGRATION - END

                if len(result) > 0:
                    libs.bt3out.print_mockfiles(result)
                    print("")
                    libs.bt3out.print_info("Available mock files: %s\n" % len(result))

                else:
                    print("")
                    libs.bt3out.print_info("No mock files were found.")
                    libs.bt3out.print_warning("%s\n" % libs.bt3out.API_JOIN_COMMUNITY)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)


        else:
            cmds = [["show mockfiles", "Display all available mock files."],
                    ["show mockfiles cloud", "Display mock files available in the cloud."],
                    ["show mockfiles disk", "Display mock files available on your computer."]]
            libs.bt3out.print_help(cmds, True, True)


    def do_version(self, args):
        print("")
        libs.bt3out.print_info("You are running %s version %s\n" % (__module_name__, __module_version__))



class Mocksum():

    def load_info(self, mockfile):
        mockfile_module = importlib.import_module("mockfiles.%s" % mockfile)
        mockfile_module = reload(mockfile_module)

        return mockfile_module.Mockfile()

