#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import cmd, os, signal
import ssl, threading, importlib, base64, zlib, zipfile
import libs.bt3out, libs.bt3in, libs.bt3api

from BaseHTTPServer import BaseHTTPRequestHandler
from BaseHTTPServer import HTTPServer
from SocketServer   import ThreadingMixIn


__module_name__    = "Maligno"
__module_version__ = "3.6"


class Options():

    def __init__(self):
        self.lhost    = ""
        self.lport    = "80"
        self.profile  = ""
        self.ssl_supp = False
        self.ssl_cert = "server.pem"


    def get_options(self):
        self.options = [["LHOST", str(self.lhost), "True", "IP address or FQDN to expose the C2 server on."],
                        ["LPORT", str(self.lport), "True", "TCP Port to listen for connections."],
                        ["PROFILE", str(self.profile), "True", "Profile containing malware network indicators."],
                        ["SSL", str(self.ssl_supp), "False", "Enable server SSL/TLS support."],
                        ["SSL_CERT", str(self.ssl_cert), "False", "Server certificate to use with SSL/TLS support."]]

        return self.options


    def validate_options(self):
        print("")
        return self.validate_mandatory_args(self.lhost, self.lport, self.profile) and self.validate_optional_args(self.ssl_supp, self.ssl_cert)


    def validate_mandatory_args(self, lhost, lport, profile):
        valid_options = True

        if not lhost or not libs.bt3in.check_host_value(lhost):
            libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_HOST)
            valid_options = False

        if not lport or not libs.bt3in.check_legal_port(lport):
            libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_PORT)
            valid_options = False

        if profile:
            base_path = "%s/%s" % (os.path.abspath(os.path.curdir), "profiles")
            profile_module_path = "%s/%s.py" % (base_path, profile)
            is_valid_path = os.path.abspath(profile_module_path).startswith(base_path)
            if not is_valid_path or not libs.bt3in.check_file_exists(profile_module_path):
                libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_PROFILE)
                valid_options = False
        else:
            libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_PROFILE)
            valid_options = False

        return valid_options


    def validate_optional_args(self, ssl_supp, ssl_cert):
        valid_options = True

        if type(ssl_supp) != type(True):
            libs.bt3out.print_error("SSL option value must be boolean (True or False).\n")
            valid_options = False

        if ssl_supp:
            if ssl_cert:
                base_path = "%s/%s" % (os.path.abspath(os.path.curdir), "certs")
                cert_path = "%s/%s" % (base_path, ssl_cert)
                is_valid_path = os.path.abspath(cert_path).startswith(base_path)
                if not is_valid_path or not libs.bt3in.check_file_exists(cert_path):
                    libs.bt3out.print_error("%s\n" % libs.bt3out.MALIGNO_SSL_SETUP)
                    valid_options = False
            else:
                libs.bt3out.print_error("%s\n" % libs.bt3out.MALIGNO_SSL_SETUP)
                valid_options = False

        return valid_options



class Menu(cmd.Cmd):

    def __init__(self):
        cmd.Cmd.__init__(self)
        self.api_credentials = []
        self.resource_cmds = []
        self.config = Options()
        self.maligno = Maligno()
        self.description_length = 100
        self.profile_folder = "./profiles"
        libs.bt3out.setup_material_folder(self.profile_folder)


    def clear_api_creds(self):
        if len(self.api_credentials) == 2:
            self.api_credentials[0] = libs.bt3api.generate_string()
            self.api_credentials[1] = libs.bt3api.generate_string()
            self.api_credentials    = []


    def complete_download(self, text, line, begidx, endidx):
        autocomplete_list = []

        if len(self.api_credentials) == 2 and line.startswith("download"):
            try:
                json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "profile")
                if json_results and libs.bt3api.validate_json(json_results):
                    parsed_results = libs.bt3api.parse_json(json_results)
                    if parsed_results[-1]["Result"]:
                        del parsed_results[-1]
                        for profile in parsed_results:
                            autocomplete_list.append(profile["Name"])

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        return [i for i in autocomplete_list if i.startswith(text)]


    def complete_set(self, text, line, begidx, endidx):
        autocomplete_list = ["lhost", "LHOST", "lport", "LPORT", "profile", "PROFILE",
                            "ssl", "SSL", "ssl_cert", "SSL_CERT"]

        if line.startswith("set PROFILE") or line.startswith("set profile"):
            try:
                profile_folder = self.profile_folder
                files = [f for f in os.listdir(profile_folder) if os.path.isfile(os.path.join(profile_folder, f))]
                files.sort()
                for profile in files:
                    if profile.endswith(".py") and profile not in ["__init__.py"]:
                        profile_name = profile.replace(".py", "")
                        autocomplete_list.append(profile_name)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        elif line.startswith("set SSL") or line.startswith("set ssl"):
            autocomplete_list.append("True")
            autocomplete_list.append("true")
            autocomplete_list.append("False")
            autocomplete_list.append("false")

        return [i for i in autocomplete_list if i.startswith(text)]


    def complete_show(self, text, line, begidx, endidx):
        autocomplete_list = ["options", "profiles", "interfaces"]
        if line.startswith("show profiles"):
            autocomplete_list.append("cloud")
            autocomplete_list.append("disk")

        return [i for i in autocomplete_list if i.startswith(text)]


    def default(self, args):
        print("")
        libs.bt3out.print_error("%s\n" % libs.bt3out.INVALID_COMMAND)


    def emptyline(self):
        pass


    def do_back(self, args):
        return True


    def do_download(self, args):
        if len(self.api_credentials) == 2:
            if libs.bt3in.get_confirmation("%s" % libs.bt3out.MATERIAL_DOWNLOAD, "WARN"):
                args = args.split(" ")
                if len(args) == 1 and args[0] not in [""]:
                    try:
                        libs.bt3out.print_info("Downloading...")
                        json_results = libs.bt3api.download_material(self.api_credentials[0], self.api_credentials[1],
                                                                     "profile", args[0], self.profile_folder)
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if not parsed_results[-1]["Result"]:
                                libs.bt3out.print_error("%s\n" % parsed_results[-1]["Msg"])
                                libs.bt3out.log_download("profile", args[0], "ERROR")

                        else:
                            zip_file_path = "%s/%s.zip" % (self.profile_folder, os.path.basename(args[0]))
                            if libs.bt3in.check_file_exists(zip_file_path) and zipfile.is_zipfile(zip_file_path):
                                zip_file = zipfile.ZipFile(zip_file_path, "r")
                                zip_file.extractall(self.profile_folder)
                                zip_file.close()
                                os.remove(zip_file_path)
                                libs.bt3out.print_ok("%s\n" % libs.bt3out.MATERIAL_INSTALLED)
                                libs.bt3out.log_download("profile", args[0], "SUCCESS")

                            else:
                                libs.bt3out.print_error("%s" % libs.bt3out.MATERIAL_DAMAGED)
                                libs.bt3out.log_download("profile", args[0], "ERROR")

                        # Display credit balance
                        json_results = libs.bt3api.get_subscription(self.api_credentials[0], self.api_credentials[1])
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if parsed_results[-1]["Result"]:
                                del parsed_results[-1]
                                for subscription in parsed_results:
                                    libs.bt3out.print_info("Your current balance is %s credit(s).\n" % subscription["CreditBalance"])

                            else:
                                print("")
                                libs.bt3out.print_error("%s\n" % parsed_results[-1]["Msg"])

                        else:
                            print("")
                            libs.bt3out.print_error("Could not retrieve your current balance.\n")

                    except Exception as e:
                        print("")
                        libs.bt3out.print_error("%s\n" % e)

        else:
            print("")
            libs.bt3out.print_error("%s\n" % libs.bt3out.API_AUTHENTICATION)


    def do_exit(self, args):
        self.clear_api_creds()
        libs.bt3out.exit_program(args)


    def do_genclient(self, args):
        if self.config.validate_options():
            libs.bt3out.print_info("Generating Maligno client...")
            self.maligno.generate_maligno_client(self.config.profile, self.config.lhost, self.config.lport, self.config.ssl_supp)


    def do_help(self, args):
        cmds = [["back", "Exit current selected module and return to main menu."],
                ["download <profile>", "Download a given profile from the Blue Team Training Toolkit cloud."],
                ["exit", "Exit the Blue Team Training Toolkit."],
                ["genclient", "Generate a client with the current configured settings."],
                ["help", "Display help menu."],
                ["run", "Run the module with the given options."],
                ["search <string>", "Find malware indicator profiles based on a given string."],
                ["set <option> <value>", "Set module option."],
                ["show interfaces", "Display available network interfaces."],
                ["show options", "Display module options."],
                ["show profiles", "Display all available malware indicator profiles."],
                ["show profiles cloud", "Display malware indicator profiles available in the cloud."],
                ["show profiles disk", "Display malware indicator profiles available on your computer."],
                ["version", "Display module version."]]
        libs.bt3out.print_help(cmds, False, True)


    def preloop(self):
        if len(self.resource_cmds) > 0:
            for cmd in self.resource_cmds:
                c = self.precmd(cmd)
                e = self.onecmd(c)

            self.resource_cmds = []


    def do_set(self, args):
        try:
            args = args.split(" ")
            option_set = False
            if len(args) == 2:
                if args[0].upper() in ["LHOST"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.lhost = ""
                    else:
                        self.config.lhost = args[1]
                    
                    option_set = True

                elif args[0].upper() in ["LPORT"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.lport = ""
                    else:
                        self.config.lport = args[1]
                    
                    option_set = True

                elif args[0].upper() in ["PROFILE"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.profile = ""
                    else:
                        self.config.profile = os.path.basename(args[1])
                    
                    option_set = True

                elif args[0].upper() in ["SSL"]:
                    if args[1].upper() in ["TRUE"]:
                        self.config.ssl_supp = True
                    else:
                        self.config.ssl_supp = False

                    option_set = True

                elif args[0].upper() in ["SSL_CERT"]:
                    if args[1].upper() in ["\"\""]:
                        self.config.ssl_cert = ""
                    else:
                        self.config.ssl_cert = os.path.basename(args[1])
                    
                    option_set = True

            if option_set:
                print("")
                if args[0] in ["PROFILE", "SSL_CERT"]:
                    libs.bt3out.print_ok("%s => %s\n" % (args[0], os.path.basename(args[1])))
                else:
                    libs.bt3out.print_ok("%s => %s\n" % (args[0], args[1]))

            else:
                cmds = [["set LHOST <IP or FQDN>", "Set an IP address or FQDN to expose the C2 server on."],
                        ["set LPORT <port>", "Set a TCP Port to listen for connections."],
                        ["set PROFILE <file>", "Set a profile containing malware network indicators."],
                        ["set SSL <bool>", "Set whether the server should have SSL/TLS support."],
                        ["set SSL_CERT <file>", "Set a server certificate to use with SSL/TLS support."]
                        ]
                libs.bt3out.print_help(cmds, True, True)

        except Exception as e:
            print("")
            libs.bt3out.print_error("%s\n" % e)


    def do_search(self, args):
        args = args.split(" ")
        if len(args) == 1 and args[0] not in [""]:
            try:
                profile_folder = self.profile_folder
                files = [f for f in os.listdir(profile_folder) if os.path.isfile(os.path.join(profile_folder, f))]
                files.sort()
                result = []
                for profile in files:
                    if profile.endswith(".py") and profile not in ["__init__.py"]:
                        profile_name = profile.replace(".py", "")
                        loaded_profile = self.maligno.load_profile(profile_name)

                        profile_date = "####-##-##"
                        profile_date = loaded_profile.info.date

                        profile_description = loaded_profile.info.description
                        if len(profile_description) == 0:
                            profile_description = libs.bt3out.NO_DESCRIPTION

                        if profile_name.find(args[0]) > -1 or profile_description.find(args[0]) > -1:
                            result.append([ profile_name, "Disk", profile_date, " ", profile_description.replace("\n", "")[:self.description_length] ])

                #API INTEGRATION - START
                if len(self.api_credentials) == 2:
                    json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "profile")
                    if json_results and libs.bt3api.validate_json(json_results):
                        parsed_results = libs.bt3api.parse_json(json_results)
                        if parsed_results[-1]["Result"]:
                            del parsed_results[-1]
                            for profile in parsed_results:
                                if profile["Name"].find(args[0]) > -1 or profile["Description"].find(args[0]) > -1:
                                    result.append([ profile["Name"], "Cloud", profile["Date"], profile["Price"], profile["Description"].replace("\n", "") ])

                        else:
                            print("")
                            libs.bt3out.print_warning("%s\n" % parsed_results[-1]["Msg"])
                    else:
                        print("")
                        libs.bt3out.print_error("%s" % libs.bt3out.API_INCOMMUNICATION)
                        libs.bt3out.print_error("%s\n" % libs.bt3out.CONTACT_SUPPORT)

                #API INTEGRATION - END

                if len(result) > 0:
                    libs.bt3out.print_profiles(result)
                    print("")
                    libs.bt3out.print_info("Search results: %s\n" % len(result))

                else:
                    print("")
                    libs.bt3out.print_info("%s\n" % libs.bt3out.NO_RESULTS)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        else:
            cmds = [["search <string>", "Find malware indicator profiles based on a given string."]]
            libs.bt3out.print_help(cmds, True, True)


    def do_show(self, args):
        if args.upper() in ["INTERFACES"]:
            libs.bt3out.print_interfaces()

        elif args.upper() in ["OPTIONS"]:
            libs.bt3out.print_options(self.config.get_options())

        elif args.upper() in ["PROFILES", "PROFILES CLOUD", "PROFILES DISK"]:
            try:
                profile_folder = self.profile_folder
                files = [f for f in os.listdir(profile_folder) if os.path.isfile(os.path.join(profile_folder, f))]
                files.sort()
                result = []

                if args.upper() in ["PROFILES", "PROFILES DISK"]:
                    for profile in files:
                        if profile.endswith(".py") and profile not in ["__init__.py"]:
                            profile_name = profile.replace(".py", "")
                            loaded_profile = self.maligno.load_profile(profile_name)

                            profile_date = "####-##-##"
                            profile_date = loaded_profile.info.date

                            profile_description = loaded_profile.info.description
                            if len(profile_description) == 0:
                                profile_description = libs.bt3out.NO_DESCRIPTION

                            result.append([ profile_name, "Disk", profile_date, " ", profile_description.replace("\n", "")[:self.description_length] ])

                #API INTEGRATION - START
                if args.upper() in ["PROFILES", "PROFILES CLOUD"]:
                    if len(self.api_credentials) == 2:
                        json_results = libs.bt3api.get_material_list(self.api_credentials[0], self.api_credentials[1], "profile")
                        if json_results and libs.bt3api.validate_json(json_results):
                            parsed_results = libs.bt3api.parse_json(json_results)
                            if parsed_results[-1]["Result"]:
                                del parsed_results[-1]
                                for profile in parsed_results:
                                    result.append([ profile["Name"], "Cloud", profile["Date"], profile["Price"], profile["Description"].replace("\n", "") ])

                            else:
                                print("")
                                libs.bt3out.print_warning("%s\n" % parsed_results[-1]["Msg"])
                        else:
                            print("")
                            libs.bt3out.print_error("%s" % libs.bt3out.API_INCOMMUNICATION)
                            libs.bt3out.print_error("%s\n" % libs.bt3out.CONTACT_SUPPORT)

                #API INTEGRATION - END

                if len(result) > 0:
                    libs.bt3out.print_profiles(result)
                    print("")
                    libs.bt3out.print_info("Available profiles: %s\n" % len(result))

                else:
                    print("")
                    libs.bt3out.print_info("No malware indicator profiles were found.")
                    libs.bt3out.print_warning("%s\n" % libs.bt3out.API_JOIN_COMMUNITY)

            except Exception as e:
                print("")
                libs.bt3out.print_error("%s\n" % e)

        else:
            cmds = [["show options", "Display module options."],
                    ["show profiles", "Display all available malware indicator profiles."],
                    ["show profiles cloud", "Display malware indicator profiles available in the cloud."],
                    ["show profiles disk", "Display malware indicator profiles available on your computer."]]
            libs.bt3out.print_help(cmds, True, True)


    def do_run(self, args):
        if self.config.validate_options():
            self.maligno.run(self.config.lhost, self.config.lport, self.config.profile,
                             self.config.ssl_supp, self.config.ssl_cert)


    def do_version(self, args):
        print("")
        libs.bt3out.print_info("You are running %s version %s\n" % (__module_name__, __module_version__))


class Maligno():

    def __init__(self):
        self.test   = None


    def CreateHTTPHandler(self, profile):

        class HTTPHandler(BaseHTTPRequestHandler):

            def do_GET(self):
                self.process_request()
                return

            def do_POST(self):
                self.process_request()
                return

            def do_HEAD(self):
                self.process_request()
                return

            def do_PUT(self):
                self.process_request()
                return

            def do_DELETE(self):
                self.process_request()
                return

            def do_TRACE(self):
                self.process_request()
                return

            def do_DEBUG(self):
                self.process_request()
                return

            def do_OPTIONS(self):
                self.process_request()
                return

            def do_PATCH(self):
                self.process_request()
                return

            def load_profile(self, profile):
                profile_module = importlib.import_module("profiles.%s" % profile)
                profile_module = reload(profile_module)
                return profile_module.Profile()

            def process_request(self):
                profile_config = self.load_profile(profile)

                header_content_length_present = False
                self.server_version = profile_config.response.banner
                self.sys_version = ""

                if profile_config.network.protocol.upper() in ["HTTP/1.1"]:
                    self.protocol_version = "HTTP/1.1"

                print("===================================================================\n")
                libs.bt3out.print_info("New request from %s..." % self.client_address[0])

                try:
                    response_body = profile_config.response.body

                    if profile_config.network.encoding.upper() in ["NONE"]:
                        response_body = response_body

                    elif profile_config.network.encoding.upper() in ["BASE64"]:
                        response_body = base64.b64encode(response_body)

                    elif profile_config.network.encoding.upper() in ["BIN"]:
                        response_body = str(zlib.compress(response_body, 1))
                        if len(response_body) > 5:
                            response_body = response_body[5:]

                    elif profile_config.network.encoding.upper() in ["HEX"]:
                        response_body = str(response_body).encode("hex")


                    # Send the response to the client
                    print("")
                    if profile_config.response.code:
                        self.send_response(int(profile_config.response.code))
                    else:
                        self.send_response(200)

                    if profile_config.response.headers:
                        for header in profile_config.response.headers:
                            if header:
                                if str(header["field"]).rstrip().lstrip().upper() in ["TRANSFER-ENCODING"] and str(header["value"]).rstrip().lstrip().upper() in ["CHUNKED"]:
                                    #Mispelling in order to avoid chunked responses
                                    self.send_header(str(header["field"]).rstrip().lstrip(), "chuncked")

                                elif str(header["field"]).rstrip().lstrip().upper() in ["CONTENT-LENGTH"]:
                                    header_content_length_present = True
                                    self.send_header(str(header["field"]).rstrip().lstrip(), len(response_body))

                                else:
                                    self.send_header(str(header["field"]).rstrip().lstrip(), str(header["value"]).rstrip().lstrip())

                            else:
                                print("")
                                libs.bt3out.print_error("There was a problem while parsing one of the server headers. Ingnoring it...\n")

                    self.end_headers()
                    self.wfile.write(response_body)
                    print("")
                    libs.bt3out.print_ok("Request served!")

                except Exception as e:
                    print("")
                    libs.bt3out.print_error("%s.\n" % e)
                    libs.bt3out.print_error("Request with unexpected format!")
                    libs.bt3out.print_info("Ending headers...\n")
                    self.end_headers()

                libs.bt3out.print_info("End of request.\n")
                print("===================================================================")
                return

        return HTTPHandler


    class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True


    def load_profile(self, profile):
        profile_module = importlib.import_module("profiles.%s" % profile)
        profile_module = reload(profile_module)

        return profile_module.Profile()


    def read_client_template(self, template_file):
        try:
            fr = open(template_file, 'r')
            content = fr.read().splitlines()
            fr.close()

        except IOError:
            libs.bt3out.print_error("Could not find %s." % template_file)
            return True

        return content


    def write_client_template(self, script_code, output_file):
        try:
            fw = open(output_file, 'w')
            for line in script_code:
                fw.write(line + "\n")

            fw.close()
            libs.bt3out.print_ok("Maligno client successfully generated! Check the \"clients\" folder.\n")

        except IOError:
            libs.bt3out.print_error("Could not save client code in %s.\n" %  output_file)

        return True


    def generate_maligno_client(self, profile, lhost, lport, ssl_supp):

        try:
            signal.signal(signal.SIGINT, libs.bt3in.allow_keyboard_interrupt)
            profile_config = self.load_profile(profile)

            if self.validate_profile(profile_config):
                output_folder = "./clients"
                output_file   = "maligno_client_%s.py" % profile
                if not os.path.exists(output_folder):
                    os.makedirs(output_folder)

                client_template = self.read_client_template("./modules/maligno_client.py")
                client_code = []
                for template_line in client_template:
                    if template_line == "<CONFIG>":
                        client_code.append("cfg_srv_addr = \"%s\"" % lhost)
                        client_code.append("cfg_srv_port = \"%s\"" % lport)
                        client_code.append("cfg_ssl      = %s" % str(ssl_supp))
                        client_code.append("")
                        client_code.append("cfg_req_proto   = \"%s\"" % profile_config.network.protocol)
                        client_code.append("cfg_req_method  = \"%s\"" % profile_config.request.method)
                        client_code.append("cfg_req_uris    = %s" % str(profile_config.request.URI))
                        client_code.append("cfg_req_body    = \"%s\"" % profile_config.request.body)
                        client_code.append("cfg_req_headers = %s" % str(profile_config.request.headers))
                        client_code.append("cfg_req_delay   = %s" % profile_config.network.delay)
                        client_code.append("cfg_req_jitter  = %s" % profile_config.network.jitter)

                    else:
                        client_code.append(template_line)

                self.write_client_template(client_code, "%s/%s" % (output_folder, output_file))
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)

        except KeyboardInterrupt:
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)
            return True

        except Exception as e:
            libs.bt3out.print_error("%s.\n" % e)
            return True


    def validate_profile(self, profile_config):
        valid_options = True
        try:
            if profile_config.request.method.upper() not in ["GET", "POST", "HEAD", "PUT", "OPTIONS", "DELETE", "TRACE", "DEBUG", "PATCH"]:
                libs.bt3out.print_error("Profile server request method must be GET, POST, HEAD, PUT, OPTIONS, DELETE, TRACE, DEBUG or PATCH.\n")
                valid_options = False

            if not profile_config.request.URI or len(profile_config.request.URI) == 0:
                libs.bt3out.print_error("Profile server request URI must be defined.\n")
                valid_options = False

            if profile_config.network.protocol.upper() not in ["HTTP/1.0", "HTTP/1.1"]:
                libs.bt3out.print_error("Profile network protocol must be HTTP/1.0 or HTTP/1.1\n")
                valid_options = False

            if profile_config.network.encoding.upper() not in ["NONE", "BASE64", "BIN", "HEX"]:
                libs.bt3out.print_error("Profile network encoding must be NONE, BASE64, BIN or HEX.\n")
                valid_options = False

            if profile_config.network.delay < 0:
                libs.bt3out.print_error("Profile network delay must be non-negative.\n")
                valid_options = False

            if profile_config.network.jitter < 0:
                libs.bt3out.print_error("Profile network jitter must be non-negative.\n")
                valid_options = False

        except Exception as e:
            print("")
            libs.bt3out.print_error("%s\n" % e)
            valid_options = False

        return valid_options


    def run(self, lhost, lport, profile, ssl_supp, ssl_cert):

        try:
            signal.signal(signal.SIGINT, libs.bt3in.allow_keyboard_interrupt)
            profile_config = self.load_profile(profile)

            if self.validate_profile(profile_config):
                server = self.ThreadedHTTPServer(('', int(lport)), self.CreateHTTPHandler(profile))
                if ssl_supp:
                    base_path = "%s/%s" % (os.path.abspath(os.path.curdir), "certs")
                    cert_path = "%s/%s" % (base_path, ssl_cert)
                    server.socket = ssl.wrap_socket(server.socket, certfile=cert_path, server_side=True)
                    libs.bt3out.print_info("SSL certificate file found. SSL enabled...")

                libs.bt3out.print_info("Maligno is up and running. Press [CTRL+C] to stop...\n")
                server.serve_forever()

            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)

        except KeyboardInterrupt:
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)
            return True

        except Exception as e:
            signal.signal(signal.SIGINT, libs.bt3in.prevent_keyboard_interrupt)
            libs.bt3out.print_error("%s.\n" % e)
            return True


