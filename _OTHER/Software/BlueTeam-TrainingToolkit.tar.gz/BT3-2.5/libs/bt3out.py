#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import os, sys, random, datetime, subprocess
import libs.bt3in


ACCOUNT_DELETED        = "Your BT3 content subscription account has been successfully deleted."
ACCOUNT_DELETION       = "Your BT3 content subscription account is going to be deleted. This process cannot be reverted.\n    Your API access, credit balance and licensed training materials will be lost."
API_AUTHENTICATION     = "This command requires Blue Team Training Toolkit API authentication."
API_DISCONNECTED       = "Disconnected from BT3 API. You are now working in offline mode."
API_INCOMMUNICATION    = "Could not communicate with the Blue Team Training Toolkit API."
API_JOIN_COMMUNITY     = "Create a BT3 content subscription account and get access to free training content ready for use with BT3."
BT3_COULD_NOT_DOWNLOAD = "An error occurred while downloading the update."
BT3_COULD_NOT_EXTRACT  = "The update file was successfully downloaded, but it could not be extracted."
BT3_COULD_NOT_UPDATE   = "Could not retrieve the latest release information from the server."
BT3_COULD_NOT_COMPLETE = "The update process could not complete."
BT3_DAMAGED_UPDATE     = "The update file may be damaged (incorrect checksum)."
BT3_DEPLOYMENT_READY   = "You may now run the installation script, or migrate your local settings and training materials."
BT3_INSTALL_UPDATE     = "The new version will be deployed in a separate folder, without modifying your current installation."
BT3_LATEST_VERSION     = "You are running the latest version of the Blue Team Training Toolkit."
BT3_MANUAL_UPDATE      = "Please, check https://www.encripto.no/tools and deploy the update manually."
CONTACT_SUPPORT        = "Please, try again later or contact support@bt3.no if the problem persists."
INVALID_VOUCHER_CODE   = "A valid voucher code must be provided."
INVALID_COMMAND        = "Command not found. Type 'help' if you need assistance."
INVALID_HOST           = "A valid host must be provided (either IP address or FQDN)."
INVALID_PORT           = "A valid port within [1-65535] must be provided."
INVALID_PROFILE        = "A valid malware indicator profile must be provided. List available profiles with 'show profiles'."
INVALID_PCAP           = "A valid PCAP file must be provided. List available PCAP files with 'show pcaps'."
INVALID_RESOURCE_FILE  = "The given resource file does not exist."
LIMIT_RESOURCE_FILE    = "Resource file commands can only run within a single module in use."
IGNORE_RESOURCE_FILE   = "Commands listed after 'back' will be ignored."
NO_DESCRIPTION         = "No description available."
NO_OPTIONS             = "This module has no options."
NO_RESULTS             = "No results were found."
NO_RUN_COMMAND         = "This module cannot be run. Please, use the 'download' command instead."
NOT_OPTIMAL_REPLAY     = "For an optimal packet payload manipulation, PCAP and WIRE payload values should have the same size.\n    Everything should work now, but non-optimal replay conditions could result in malformed packets (depends on the protocol)."
MALIGNO_SSL_SETUP      = "A valid SSL certificate file (located in 'certs' / PEM format) must be provided."
MALWARE_FILES          = "PCAP material may contain infected files."
MATERIAL_DAMAGED       = "The downloaded training material is damaged or could not be written to disk."
MATERIAL_DOWNLOAD      = "Training material will be downloaded from the cloud (costs may apply)."
MATERIAL_INSTALLED     = "Congratulations! New training material is now available on your disk."
OFFLINE_MODE           = "Authentication failed. You are working in offline mode."
PASSWORD_POLICY        = "The minimum length is 10 characters, as well as a mix of lowcase and uppercase letters, digits and punctuation characters."
PASSWORD_NOT_MATCHED   = "The passwords do not match."
RESET_CREDS_RESTART    = "You can restart this process by typing 'apinewcreds'."
VOUCHER_REDEEMED       = "Congratulations! Your voucher has been redeemed successfully."
WARNING_EXPORT_OBJ     = "Use caution when exporting objects from the network traffic."
WEAK_PASSWORD          = "The password is too weak."


def print_ok(msg):
    print("\033[1;32m[+]\033[1;m {0}".format(msg))


def print_warning(msg):
    print("\033[1;33m[!]\033[1;m {0}".format(msg))

def print_error(msg):
    print("\033[1;31m[-]\033[1;m {0}".format(msg))


def print_info(msg):
    print("\033[1;34m[*]\033[1;m {0}".format(msg))


def print_title(msg):
    print("\033[1;37m{0}\033[1;m".format(msg))


def print_prompt(module_name):
    prompt = None
    if module_name:
        prompt = "\033[1;37m{0} ~ \033[1;m\033[1;34m{1}\033[1;m\033[1;37m{2}\033[1;m".format("BT3", "%s" % module_name, " > " )
    else:
        prompt = "\033[1;37m{0}\033[1;m".format("BT3 > ")

    return prompt


def exit_program(args):
    print("")
    print_info("BT3 is now shutting down...\n")
    sys.exit()


def print_help(help_content, error, command):
    print("")
    if error:
        print_error("Command not found. Did you mean...?\n")

    width = [16, 16]
    help_lines = []

    if command:
        help_lines.append(["Command", "Description"])
        help_lines.append(["-------", "-----------"])

    else:
        help_lines.append(["Module", "Description"])
        help_lines.append(["------", "-----------"])

    for cmd in help_content:
        index = 0
        line = []
        for value in cmd:
            if value:
                current_width = len(str(value))
                line.append(str(value))
                if width[index] < current_width:
                    width[index] = current_width + 2
                index += 1

        help_lines.append(line)

    for line in help_lines:
        print("    %-*s  %-*s" % (width[0], str(line[0]), width[1], str(line[1])))

    print("")


def print_interfaces():
    try:
        proc_ifconfig = subprocess.Popen("/sbin/ifconfig", stdout=subprocess.PIPE, shell=True)
        print("\n%s" % proc_ifconfig.communicate()[0])

    except Exception as e:
        print("")
        print_error("%s\n" % e)


def print_mockfiles(content):
    print_pcaps(content)


def print_pcaps(content):
    print("")
    width = [16, 11, 10, 6, 7, 13]
    content_lines = []

    content_lines.append(["File", "Size (MB)", "Location", "Date", "Price", "Description"])
    content_lines.append(["----", "---------", "--------", "----", "-----", "-----------"])

    for prof in content:
        index = 0
        line = []
        for value in prof:
            if value:
                current_width = len(str(value))
                line.append(str(value))
                if width[index] < current_width:
                    width[index] = current_width + 2
                index += 1

        content_lines.append(line)

    for line in content_lines:
        print("    %-*s  %-*s  %-*s  %-*s  %-*s  %-*s" % (width[0], str(line[0]), width[1], str(line[1]),
                                                          width[2], str(line[2]), width[3], str(line[3]),
                                                          width[4], str(line[4]), width[5], str(line[5])))

    print("")


def print_profiles(content):
    print("")
    width = [16, 10, 6, 7, 13]
    content_lines = []

    content_lines.append(["Profile", "Location", "Date", "Price", "Description"])
    content_lines.append(["-------", "--------", "----", "-----", "-----------"])

    for prof in content:
        index = 0
        line = []
        for value in prof:
            if value:
                current_width = len(str(value))
                line.append(str(value))
                if width[index] < current_width:
                    width[index] = current_width + 2
                index += 1

        content_lines.append(line)

    for line in content_lines:
        print("    %-*s  %-*s  %-*s  %-*s  %-*s" % (width[0], str(line[0]), width[1], str(line[1]),
                                                     width[2], str(line[2]), width[3], str(line[3]),
                                                     width[4], str(line[4])))

    print("")


def print_options(options):
    print("")
    width = [16, 10, 10, 13]
    option_lines = []
    option_lines.append(["Name", "Setting", "Required", "Description"])
    option_lines.append(["----", "-------", "--------", "-----------"])
    for option in options:
        index = 0
        line = []
        for value in option:
            current_width = len(str(value))
            line.append(str(value))
            if width[index] < current_width:
                width[index] = current_width + 2
            index += 1

        option_lines.append(line)

    for line in option_lines:
        print("    %-*s  %-*s  %-*s  %-*s" % (width[0], str(line[0]), width[1], str(line[1]),
                                              width[2], str(line[2]), width[3], str(line[3])))

    print("")


def print_banner(version, author):
    os.system("clear")
    if random.randint(1, 10) % 2 == 0:
        print("                                                                      ")
        print("\033[1;34m              ____  _              _____                              \033[1;m")
        print("\033[1;34m             | __ )| |_   _  ___  |_   _|__  __ _ _ __ ___            \033[1;m")
        print("\033[1;34m             |  _ \| | | | |/ _ \   | |/ _ \/ _` | '_ ` _ \           \033[1;m")
        print("\033[1;34m             | |_) | | |_| |  __/   | |  __/ (_| | | | | | |          \033[1;m")
        print("\033[1;34m             |____/|_|\__,_|\___|   |_|\___|\__,_|_| |_| |_|          \033[1;m")
        print("                                                                      ")
        print("\033[1;34m  _____          _       _               _____           _ _    _ _   \033[1;m")
        print("\033[1;34m |_   _| __ __ _(_)_ __ (_)_ __   __ _  |_   _|__   ___ | | | _(_) |_ \033[1;m")
        print("\033[1;34m   | || '__/ _` | | '_ \| | '_ \ / _` |   | |/ _ \ / _ \| | |/ / | __|\033[1;m")
        print("\033[1;34m   | || | | (_| | | | | | | | | | (_| |   | | (_) | (_) | |   <| | |_ \033[1;m")
        print("\033[1;34m   |_||_|  \__,_|_|_| |_|_|_| |_|\__, |   |_|\___/ \___/|_|_|\_\_|\__|\033[1;m")
        print("\033[1;34m                                 |___/                                \033[1;m")
        print("                                                                      ")

    else:
        print("                                                                      ")
        print("\033[1;34m                  ______       _________    \033[1;m\033[1;37m  ______  \033[1;m")
        print("\033[1;34m                 |_   _ \     |  _   _  |   \033[1;m\033[1;37m / ____ `.\033[1;m")
        print("\033[1;34m                   | |_) |    |_/ | | \_|   \033[1;m\033[1;37m `'  __) |\033[1;m")
        print("\033[1;34m                   |  __'.        | |       \033[1;m\033[1;37m _  |__ '.\033[1;m")
        print("\033[1;34m                  _| |__) |      _| |_      \033[1;m\033[1;37m| \____) |\033[1;m")
        print("\033[1;34m                 |_______/      |_____|     \033[1;m\033[1;37m \______.'\033[1;m")
        print("                                                                      ")


    print("                                                                          ")
    print("\033[1;37m ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\033[1;m")
    print("                                                                          ")
    print("\033[1;32m                 Blue Team Training Toolkit (BT3) v{0}\033[1;m".format(version))
    print("\033[1;32m           {0}\033[1;m".format(author))
    print("                                                                          ")
    print("\033[1;37m ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\033[1;m")
    print("                                                                          ")
    print("\033[1;34m                          BT3 has API powers!\033[1;m")
    print("           Create your account with \033[1;32mapisignup\033[1;m and get access")
    print("      to free and premium training content ready for use with BT3       ")
    print("                                                                          ")
    print("                                                                          ")


def print_subscription_details(subscription):
    print("")
    libs.bt3out.print_info("Blue Team Training Toolkit - Content Subscription Details")
    print("")
    print("             User: %s %s" % (subscription["FirstName"].encode("UTF-8"), subscription["LastName"].encode("UTF-8")))
    print("           E-mail: %s" % subscription["Email"])
    print("          License: %s" % subscription["LicenseType"])

    if subscription["LastLogin"] in ["0000-00-00 00:00:00"]:
        print("       Last login: Never")

    else:
        print("       Last login: %s (UTC)" % subscription["LastLogin"])

    if subscription["LastFailedLogin"] in ["0000-00-00 00:00:00"]:
        print("Last failed login: Never")

    else:
        print("Last failed login: %s (UTC)" % subscription["LastFailedLogin"])

    print("")
    print("")
    libs.bt3out.print_info("Blue Team Training Toolkit - Content Credit Details")
    print("")
    print("          Balance: %s credit(s)" % subscription["CreditBalance"])
    if subscription["CreditLastRenewalDate"] in ["0000-00-00 00:00:00"]:
        print("    Last Purchase: Never")

    else:
        print("    Last Purchase: %s (UTC)" % subscription["CreditLastRenewalDate"])


    if subscription["CreditExpiryDate"] in ["0000-00-00 00:00:00"]:
        print("    Credit Expiry: \033[1;31mExpired\033[1;m")

    else:
        expiryDate = datetime.datetime.strptime(subscription["CreditExpiryDate"], "%Y-%m-%d %H:%M:%S")
        if expiryDate > datetime.datetime.utcnow():
            print("    Credit Expiry: \033[1;32m%s (UTC)\033[1;m" % subscription["CreditExpiryDate"])

        else:
            print("    Credit Expiry: \033[1;31m%s (UTC)\033[1;m" % subscription["CreditExpiryDate"])
    print("")
    print("")
    libs.bt3out.print_info("Blue Team Training Toolkit - Content %s License" % subscription["LicenseType"])
    print("")
    print("%s" % subscription["LicenseDescription"])
    print("")


def setup_material_folder(output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    init_file = "./%s/__init__.py" % output_folder
    if not os.path.exists(init_file):
        f = open(init_file, "w")
        f.write("#!/usr/bin/python\n\n")
        f.write("################################################################\n")
        f.write("#                                                              #\n")
        f.write("# Blue Team Training Toolkit (BT3)                             #\n")
        f.write("# written by Juan J. Guelfo @ Encripto AS                      #\n")
        f.write("# post@encripto.no                                             #\n")
        f.write("#                                                              #\n")
        f.write("# Copyright 2013-%s Encripto AS. All rights reserved.        #\n" % datetime.datetime.utcnow().year)
        f.write("#                                                              #\n")
        f.write("# BT3 is licensed under the FreeBSD license.                   #\n")
        f.write("# http://www.freebsd.org/copyright/freebsd-license.html        #\n")
        f.write("#                                                              #\n")
        f.write("################################################################\n")
        f.close()




def log_download(material_type, material_name, result):
    try:
        log_file = "downloads.log"
        f = open(log_file, "a")
        f.write("Timestamp: %s\nMaterial type: %s\nMaterial name: %s\nResult: %s\n\n" % (datetime.datetime.utcnow(),
                                                                                         material_type, material_name, result))
        f.close()

    except Exception as e:
        print_error("%s\n" % e)


