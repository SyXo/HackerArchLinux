#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import os, urllib2, tarfile, hashlib
import libs.bt3in, libs.bt3out


__version__ = "2.5"
__author__  = "By Juan J. Guelfo | Encripto AS | post@encripto.no"


def deploy_update(url, checksum, version):
    libs.bt3out.print_info("Downloading update file...")

    try:
        filename   = url.split("/")[-1]
        http_req   = urllib2.Request(url, headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + __version__ + ")"})
        https_conn = urllib2.urlopen(http_req)
        data       = https_conn.read()

        with open(filename, "wb") as update:
            update.write(data)

        if libs.bt3in.check_file_exists(filename):
            sha256sum = ""
            with open(filename, "rb") as tarball:
                sha256sum = hashlib.sha256(tarball.read()).hexdigest()

            libs.bt3out.print_info("Verifying update file integrity...")
            if checksum == sha256sum:
                extract_tarball(filename, version)

            else:
                os.remove(filename)
                raise Exception(libs.bt3out.BT3_DAMAGED_UPDATE)

        else:
            raise Exception(libs.bt3out.BT3_COULD_NOT_DOWNLOAD)

    except Exception as e:
        libs.bt3out.print_error("%s\n" % e)
        libs.bt3out.print_error("%s" % libs.bt3out.BT3_COULD_NOT_COMPLETE)
        libs.bt3out.print_info("%s\n" % libs.bt3out.BT3_MANUAL_UPDATE)


def extract_tarball(filename, version):
    path = os.path.dirname(os.path.abspath(__file__)).split("/")

    # Get out from libs
    if len(path) > 1:
        del path[-1]

    # Get out from current installation folder
    if len(path) > 1:
        del path[-1]

    destination = "/"
    for directory in path:
        if directory:
            destination += "%s/" % directory

    try:
        if libs.bt3in.check_file_exists(filename) and filename.endswith("tar.gz"):
            foldername = filename.replace(".tar.gz", "")
            libs.bt3out.print_info("Extracting update file to '%s%s'..." % (destination, foldername))
            tar = tarfile.open(filename, "r:gz")
            tar.extractall(destination)
            tar.close()

            if libs.bt3in.check_folder_exists("%s%s" % (destination, foldername)):
                libs.bt3out.print_info("Removing update file...")
                os.remove(filename)

                print("")
                libs.bt3out.print_info("The new deployment is now located at '%s%s'." % (destination, foldername))
                libs.bt3out.print_info("%s\n" % libs.bt3out.BT3_DEPLOYMENT_READY)
                libs.bt3out.print_ok("Blue Team Training Toolkit v%s has been successfully deployed.\n" % version)

            else:
                os.remove(filename)
                raise Exception(libs.bt3out.BT3_COULD_NOT_EXTRACT)

        else:
            raise Exception(libs.bt3out.BT3_COULD_NOT_EXTRACT)

    except Exception as e:
        libs.bt3out.print_error("%s\n" % e)
        libs.bt3out.print_error("%s" % libs.bt3out.BT3_COULD_NOT_COMPLETE)
        libs.bt3out.print_info("%s\n" % libs.bt3out.BT3_MANUAL_UPDATE)

