#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import httplib


def install_counter(version):
    try:
        http_conn = httplib.HTTPSConnection("www.replylink.net", 443, timeout=5)
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + version + ")"}
        http_conn.request("HEAD", "/tools/stats.php", None, headers)
        http_resp = http_conn.getresponse()
        http_conn.close()

    except:
        print("")

    return


__version__ = "2.5"
install_counter(__version__)
