#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import os, re, subprocess, ipcalc, string
import libs.bt3out


def allow_keyboard_interrupt(s, f):
    print("\n")
    libs.bt3out.print_warning("CTRL+C was pressed. Aborting...\n")
    raise KeyboardInterrupt


def prevent_keyboard_interrupt(s, f):
    print("\n")
    libs.bt3out.print_info("Please, use \"exit\" instead.")


def get_confirmation(msg, msg_type):
    c = ""
    options = ["Y", "N", "y", "n"]
    while c not in options:
        print("")

        if msg_type.upper() == "OK":
            libs.bt3out.print_ok(msg)

        elif msg_type.upper() == "WARN":
            libs.bt3out.print_warning(msg)

        elif msg_type.upper() == "INFO":
            libs.bt3out.print_info(msg)

        c = raw_input("    Would you like to continue? [Y/N]: ")
        print("")
        if c.upper() == "N":
            return False

        elif c.upper() == "Y":
            return True


def get_license_type(msg):
    c = ""
    options = ["P", "p", "E", "e"]
    while c not in options:
        c = raw_input(msg)
        print("")
        if c.upper() == "P":
            return "Personal"

        elif c.upper() == "E":
            return "Enterprise"

        else:
            libs.bt3out.print_error("Please, enter [P] for Personal or [E] for Enterprise license.\n")


def check_file_exists(filename):
    return os.path.exists(filename) and os.path.isfile(filename)


def check_folder_exists(filename):
    return os.path.exists(filename) and not os.path.isfile(filename)


def check_mac_address(mac):
    return re.match("[0-9a-f]{2}([:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", mac.lower())


def check_ip_address(ip):
    legal = False
    try:
        subnet = ipcalc.Network(ip)
        legal = True

    except ValueError:
        legal = False

    return legal


def check_legal_fqdn(fqdn):
    reg = None
    legal = False
    try:
        if len(fqdn) > 0 and len(fqdn) < 255:
            if fqdn[-1] in ["."]:
                fqdn = fqdn[:-1]

            reg = re.compile("(?!-)[A-Z\d-]{1,63}(?<!-)$", re.IGNORECASE)
            legal = all(reg.match(v) for v in fqdn.split("."))
    except:
        legal = False

    return legal


def check_host_value(host):
    legal_ip = check_ip_address(host)
    legal_fqdn = check_legal_fqdn(host)
    legal_host = True

    if not legal_ip and not legal_fqdn:
        legal_host = False

    return legal_host


def check_legal_port(port):
    legal_port = True
    try:
        if int(port) < 1 or int(port) > 65535:
            legal_port = False
            
    except:
        legal_port = False

    return legal_port


def check_network_interface(interface):
    cmd = "ifconfig -a"
    output = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).communicate()[0]
    result = str(output).find(interface)

    return result > -1


def check_password_policy(pwd):
    contains_lowcase   = False
    contains_uppercase = False
    contains_digit     = False
    contains_symbol    = False

    if len(pwd) >= 10:
        for p in pwd:
            if string.ascii_lowercase.find(p) > -1:
                contains_lowcase = True

            elif string.ascii_uppercase.find(p) > -1:
                contains_uppercase = True

            elif string.digits.find(p) > -1:
                contains_digit = True

            elif string.punctuation.find(p) > -1:
                contains_symbol = True

    pwd = tmp_new_pwd = libs.bt3api.generate_string()

    return contains_lowcase and contains_uppercase and contains_digit and contains_symbol

