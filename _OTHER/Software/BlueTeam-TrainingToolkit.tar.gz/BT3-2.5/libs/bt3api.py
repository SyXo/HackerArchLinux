#!/usr/bin/python

################################################################
#                                                              #
# Blue Team Training Toolkit (BT3)                             #
# written by Juan J. Guelfo @ Encripto AS                      #
# post@encripto.no                                             #
#                                                              #
# Copyright 2013-2017 Encripto AS. All rights reserved.        #
#                                                              #
# BT3 is licensed under the FreeBSD license.                   #
# http://www.freebsd.org/copyright/freebsd-license.html        #
#                                                              #
################################################################


import os, httplib, urllib, json
import random, string, hashlib, binascii
import libs.bt3out, libs.bt3ver


__API_HOST__ = "www.bt3.no"
__API_PORT__ = 443
__API_TOUT__ = 10


def download_material(username, password, material_type, material_name, target_folder):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "pwd" : password, "type" : material_type, "name" : material_name })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/material/getFile.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()

        if result and not validate_json(result):
            fw = open("%s/%s.zip" % (target_folder, os.path.basename(material_name)), "wb")
            fw.write(result)
            fw.close()
            result = None

    except Exception as e:
        result = None

    return result


def generate_string(size=100, chars=string.ascii_uppercase +  string.ascii_lowercase):
    return ''.join(random.choice(chars) for _ in range(size))


def get_material_list(username, password, material_type):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "pwd" : password, "type" : material_type })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/material/getList.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()

    except Exception as e:
        result = None

    return result


def get_subscription(username, password):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "pwd" : password })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/subscriber/getSubscription.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()

    except Exception as e:
        result = None

    return result


def get_welcome_info(username, password):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "pwd" : password })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/subscriber/getWelcomeInfo.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()

    except Exception as e:
        result = None

    return result


# The purpose of this hashing is to prevent the exposure of clear-text passwords in memory.
# The API takes care of data protection at rest independently from this mechanism.
def hash_password(pwd, salt, iterations):

    pwd = pwd.replace("\n", "")
    salt = salt.replace("\n", "")
    result = binascii.hexlify(hashlib.pbkdf2_hmac("sha256", pwd.encode(), salt.encode(), iterations))
    pwd = generate_string()
    return result


def new_credentials_step_1(username):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/subscriber/newCredsStep1.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()

    except Exception as e:
        result = None

    return result


def new_credentials_step_2(username, token, pwd1, pwd2):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "token" : token, "pwd1" : pwd1, "pwd2" : pwd2 })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/subscriber/newCredsStep2.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()
        body = libs.bt3api.generate_string()

    except Exception as e:
        result = None

    pwd1 = libs.bt3api.generate_string()
    pwd2 = libs.bt3api.generate_string()

    return result


def redeem_credit_voucher(username, password, code):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "pwd" : password, "code" : code })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/credit/redeemCode.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()
        body = libs.bt3api.generate_string()

    except Exception as e:
        result = None

    return result


def register_account(first_name, last_name, license, username):
    result = None
    try:
        body    = urllib.urlencode({ "firstname" : first_name, "lastname" : last_name, "license" : license, "email" : username })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/subscriber/createSubscriber.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()
        body = libs.bt3api.generate_string()

    except Exception as e:
        result = None

    return result


def delete_account(username, password):
    result = None
    try:
        body    = urllib.urlencode({ "usr" : username, "pwd" : password })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/subscriber/deleteSubscriber.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()
        body = libs.bt3api.generate_string()

    except Exception as e:
        result = None

    return result


def check_current_version(version):
    result = None
    try:
        body    = urllib.urlencode({ "version" : version })
        headers = { "User-Agent" : "Mozilla/5.0 (compatible; BT3/" + libs.bt3ver.__version__ + ")",
                    "Content-type": "application/x-www-form-urlencoded",
                    "Content-Length" : len(body) }

        http_conn = httplib.HTTPSConnection(__API_HOST__, __API_PORT__, timeout=__API_TOUT__)
        http_conn.request("POST", "/BT3/api/update/checkCurrentVersion.php", body, headers)
        http_resp = http_conn.getresponse()
        result = http_resp.read()
        if http_resp.status != 200:
            result = None

        http_conn.close()
        body = libs.bt3api.generate_string()

    except Exception as e:
        result = None

    return result


def parse_json(data):
    return json.loads(data)


def validate_json(data):
    is_json = False
    try:
        json.loads(data)
        is_json = True

    except:
        is_json = False

    return is_json


